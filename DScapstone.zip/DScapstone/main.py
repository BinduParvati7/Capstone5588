import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify
import warnings
warnings.filterwarnings('ignore')
from tensorflow.keras.models import load_model

app = Flask(__name__)


model = load_model('C:/Users/navya/Downloads/ccfraudmodel.h5')  # Load the saved model


@app.route('/')
def index():
    return render_template('creditcardfraudanalysis.html')


@app.route('/execute-python', methods=['POST'])
def execute_python():
    card_number = request.form.get('card-number')
    name = request.form.get('name')
    amount = request.form.get('amount')
    zip_code = request.form.get('zip')
    # Assuming your model expects input features as JSON in the request
    features = np.array([[2023, 11, 21, 11, 12, 18, int(card_number), float(amount), 1, 561, 28654, 36.08, -81.18, 3495, 1988, 3, 9, 1325376018, 36.01, -82.05, 23, 1234]])

    # Make a prediction
    prediction = model.predict(features)

    # Depending on your problem, format the prediction as needed
    # For example, in a binary classification problem
    binary_prediction = 1 if prediction > 0.5 else 0
    return jsonify({'binary_prediction': binary_prediction})



if __name__ == '__main__':
    app.run(debug=True)

